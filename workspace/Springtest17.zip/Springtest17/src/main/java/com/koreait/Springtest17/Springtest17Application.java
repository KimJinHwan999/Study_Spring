package com.koreait.Springtest17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtest17Application {

	public static void main(String[] args) {
		SpringApplication.run(Springtest17Application.class, args);
	}

}
