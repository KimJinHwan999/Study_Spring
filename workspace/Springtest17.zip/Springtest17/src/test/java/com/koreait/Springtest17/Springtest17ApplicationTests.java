package com.koreait.Springtest17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springtest17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
