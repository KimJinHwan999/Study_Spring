package com.koreait.Springtest18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtest18Application {

	public static void main(String[] args) {
		SpringApplication.run(Springtest18Application.class, args);
	}

}
