package com.koreait.Springtest19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtest19Application {

	public static void main(String[] args) {
		SpringApplication.run(Springtest19Application.class, args);
	}

}
